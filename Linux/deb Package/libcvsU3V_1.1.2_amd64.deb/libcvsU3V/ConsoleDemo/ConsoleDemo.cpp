/*****************************************************************************/
/*
 *  ConsoleDemo.cpp -- sample application to use discover, open, configure
 *                     and stream from a USB3 Vision device
 *
 *  (c) Copyright 2023 CREVIS
 *
 *****************************************************************************
 * This sample demonstrates how to use the Crevis USB3 Vision library to
 * discover and open a USB3 Vision device. Reading and writing devices registers
 * and stream images is also demonstrated.
 * For reference of the uses USB3 Vision library function, refer to its documentation.
 * The code is delivered "as is" without any warranty and can be freely used
 * for own applications.
 */
/*****************************************************************************/
#include <termios.h> 
#include <fcntl.h>
#include <pthread.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <time.h>
#include <sys/time.h>

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <cmath>
#include <sys/select.h>

#include "cvsU3V.h"   

typedef struct
{
    BOOL Kill;
    BYTE Device;
}DEVICE_PARAMS, *PDEVICE_PARAMS;

// global variables
DEVICE_PARAMS DeviceParams;
pthread_t ThreadAcquisition;

// functions
void* ThreadProc(void* lpv);
int _kbhit();
DWORD GetTickCount(void);

// main program
int main(int argc, char* argv[])
{
    INT32 nError = MCAM_ERR_SUCCESS;
    UINT32 nNumberOfCamera = 0;
    UINT32 i;
    char szBuffer[256] = { 0, };
    UINT32 nSize = 0;
    
    INT32 nDevice = 0;
    INT32 hDevice = -1;
    char szDeviceID[256] = {0,};
    
    DWORD nTimeStart = 0, nTimeStop = 0;
    
    printf("[INFO] - UpdateDeviceList\n");
    
    // initialize systemd
    nError = ST_InitSystem();
    if(nError)
    {
        printf("[ERROR] - ST_InitSystem: %d\n", nError);
        return nError;
    }
    printf("[INFO] - InitSystem Success\n");
    
    // update device List
    nError = ST_UpdateDevice();
    if(nError)
    {
        printf("[ERROR] - ST_UpdateDevice: %d\n", nError);
        ST_FreeSystem();
        return nError;
    }
    
    nError = ST_GetAvailableCameraNum(&nNumberOfCamera);
    if(nError)
    {
        printf("[ERROR] - ST_GetAvailableCameraNum: %d\n", nError);
        ST_FreeSystem();
        return nError;
    }
    
    printf("[INFO] - UpdateDeviceList\n");
    printf("[INFO] - Found %d devices\n", nNumberOfCamera);
    
    if(nNumberOfCamera == 0)
    {
        printf("[INFO] - No device found\n");
        ST_FreeSystem();
        return 0;
    }
    
    // print out device info
    for(i = 0; i < nNumberOfCamera;i++)
    {
        nSize = 64;
        nError = ST_GetEnumDeviceID(i, szBuffer, &nSize);
        if(nError)
        {
            printf("[Error] - ST_GetEnumDeviceID: %d\n", nError);
            ST_FreeSystem();
            return nError;
        }
        
        printf("[INFO] - %d: Found Device -> %s\n",i, szBuffer);
        
        nSize = 64;
        nError = ST_GetEnumDeviceInfo(i, MCAM_DEVICEINFO_CURRENT_SPEED, szBuffer, &nSize);
        printf("[INFO] - %d: CurrentSpeed -> %s\n",i, szBuffer);
    }
    
    if(nNumberOfCamera > 1)
    {
        printf("Select Device: ");
        if(scanf("%d", &i) != 1)
        {
            printf("[ERROR] - Expected at only one numbers as input");
        }
        nDevice = i;
        printf("device: %d\n",nDevice);
    }
    
    nSize = 64;
    nError = ST_GetEnumDeviceID(nDevice, szBuffer, &nSize);
    if(nError)
    {
        printf("[Error] - ST_GetEnumDeviceID: %d\n", nError);
        ST_FreeSystem();
        return nError;
    }    
    strcpy(szDeviceID, szBuffer);
    
    nError = ST_SetSchemaPath("./Resources/");
    
    nTimeStart = GetTickCount();

    nError = ST_OpenDevice(nDevice, &hDevice);
    if(nError)
    {
        printf("[Error] - ST_OpenDevice: %d\n", nError);
        ST_FreeSystem();
        return nError;
    }

    nError = ST_OpenEvent(hDevice, 200);
    if(nError)
    {
        printf("[Error] - ST_OpenEvent: %d\n", nError);
    }
    
    nTimeStop = GetTickCount();
    printf("[INFO] - OpenDevice Success: %s\n", szDeviceID);
    printf("[INFO] - Elapsed time to open: %d ms\n", nTimeStop-nTimeStart);
    
    printf("[INFO] - Start acquisition continuous mode with any key.\n");
    printf("[INFO] - Cancel acquisition with any key.\n");
       
    int nPayloadSize = 0;
    nError = ST_GetIntReg(nDevice, MCAM_PAYLOAD_SIZE, &nPayloadSize);
    if(nError)
    {
        printf("[ERROR] - ST_GetIntReg(PayloadSize): %d\n", nError);
    }
    
    // start acquisition thread
    DeviceParams.Kill = FALSE;
    DeviceParams.Device = hDevice;
    
    getchar();
    pthread_create(&ThreadAcquisition, 0, ThreadProc, (void*)&DeviceParams);
    
    while(!_kbhit())   
    {
        usleep(100*1000);
        if(DeviceParams.Kill == TRUE)
            break;
    }
    
    DeviceParams.Kill = TRUE;
    
    pthread_join(ThreadAcquisition, 0);
    ThreadAcquisition = 0;

    nError = ST_CloseEvent(hDevice);
    if(nError)
    {
        printf("[ERROR] - ST_CloseEvent: %d\n", nError);
    }
    
    nError = ST_CloseDevice(hDevice);
    if(nError)
    {
        printf("[ERROR] - ST_CloseDevice: %d\n", nError);
        return nError;
    }
    printf("[INFO] - CloseDevice Success: %s\n", szDeviceID);
            
    nError = ST_FreeSystem();
    if(nError)
    {
        printf("[ERROR] - ST_FreeSystem: %d\n", nError);
        return nError;
    }
    printf("[INFO] - FreeSystem Success\n");
}

int _kbhit()
{
    // Get the parameters associated with STDIN_FILENO (= the default standard
    // input file descriptor number).
    struct termios OldConfig;
    // File descriptor number
    const int FileDescriptor = STDIN_FILENO;
    tcgetattr(FileDescriptor, &OldConfig);
    // Copy the original configuraiton.
    struct termios NewConfig(OldConfig);
    // Do not echo & disable canonical processing.
    NewConfig.c_lflag &= ~(ICANON | ECHO);
    // Apply new configuration.
    tcsetattr(FileDescriptor, TCSANOW, &NewConfig);
    // Get the file status flags and file access modes.
    int OldFlags = fcntl(FileDescriptor, F_GETFL, 0);
    // Set the file status flags; set non-blocking.
    fcntl(FileDescriptor, F_SETFL, OldFlags | O_NONBLOCK);
    // Get an input.
    int Ch = getchar();
    // Revert STDIN_FILENO to the original configuration.
    tcsetattr(FileDescriptor, TCSANOW, &OldConfig);
    fcntl(FileDescriptor, F_SETFL, OldFlags);
    // Check the character if it's a chanracter which is not EOF.
    int Hit = 0; // false
    if (Ch != EOF) {
        // Put it back to evaluate it at the following block.
        ungetc(Ch, stdin);
        Hit = 1; // true: Hit a valid character.
    }
    return Hit;
}

void* ThreadProc(void* lpv)
{
    INT32 nError = MCAM_ERR_SUCCESS;
    INT32 nErrorImage = MCAM_ERR_SUCCESS;
    
    PDEVICE_PARAMS dparams;
    INT32 nWidth, nHeight, nBufferSize;
    INT32 nPayloadSize;
    UINT32 nSize = 0;
    char pPixelFormat[32];
    INT32 nBpp;
    BYTE *pPixel;
    UINT64 nImageCounter;
    double nFps = 0.0, nTime;
    DWORD nTimeStart = 0, nTimeStop = 0;
    UINT64 nNumImagesAcquired = 0, nNumImagesMissing = 0;

    pPixel = NULL;
    dparams = (PDEVICE_PARAMS)lpv;
    
    // get image width
    nError = ST_GetIntReg(dparams->Device, MCAM_WIDTH, &nWidth);
    if(nError)
    {
        printf("[ERROR] - ST_GetIntReg(Width): %d\n", nError);
        goto END;
    }
    
    // get image height
    nError = ST_GetIntReg(dparams->Device, MCAM_HEIGHT, &nHeight);
    if(nError)
    {
        printf("[ERROR] - ST_GetIntReg(Height): %d\n", nError);
        goto END;
    }
    
    // get pixel format
    nSize = 32;
    nError = ST_GetEnumReg(dparams->Device, MCAM_PIXEL_FORMAT, pPixelFormat, &nSize);
    if(nError)
    {
        printf("[ERROR] - ST_GetEnumReg(PixelFormat): %d\n", nError);
        goto END;
    }
    
    if( ( strstr(pPixelFormat, "Mono8") != NULL ) || ( strstr(pPixelFormat, "BayerRG8") != NULL ) || ( strstr(pPixelFormat, "BayerGR8") != NULL )  ||
       ( strstr(pPixelFormat, "BayerBG8") != NULL ) || ( strstr(pPixelFormat, "BayerGB8") != NULL ))
        nBpp = 1;
    else if( strstr(pPixelFormat, "YUV") != NULL )
        nBpp = 2;
    else if( ( strstr(pPixelFormat, "RGB") != NULL ) || ( strstr(pPixelFormat, "BGR") != NULL ))
        nBpp = 3;
    else
    {
        printf("[ERROR] - This Pixelformat is not supported by the VirtualFG40 library.");
        goto END;
    }
    
    nBufferSize = ((nWidth * nBpp) * nHeight);
    
    nError = ST_GetIntReg(dparams->Device, MCAM_PAYLOAD_SIZE, &nPayloadSize);
    if(nError)
    {
        printf("[ERROR] - ST_GetIntReg(PayloadSize): %d\n", nError);
        goto END;
    }
    
    printf("[INFO] - Width: %d\n",nWidth);
    printf("[INFO] - Height: %d\n",nHeight);
    printf("[INFO] - BPP: %d\n",nBpp);
    printf("[INFO] - PixelFormat: %s\n",pPixelFormat);
    printf("[INFO] - ImageSize: %d\n",nBufferSize);
    printf("[INFO] - PayloadSize: %d\n",nPayloadSize);
    
    // alloc memory for the images
    pPixel = (BYTE *)malloc(nPayloadSize);

    nTimeStart = GetTickCount();

    // start acquisition continuous mode
    nError = ST_AcqStart(dparams->Device);
    if(nError)
    {
        printf("[ERROR] - ST_AcqStart: %d\n", nError);
        goto END;
    }
    
    nTimeStop = GetTickCount();
    printf("[INFO] - Elapsed time to Acqusition Start : %d ms\n", nTimeStop - nTimeStart);
    
    nImageCounter = 0;
    
    nTimeStart = GetTickCount();
    dparams->Kill = FALSE;
    while ( !dparams->Kill )
    {
        nErrorImage = ST_GrabImage(dparams->Device, pPixel, nPayloadSize);
        if(nErrorImage)
        {
            if(nErrorImage == MCAM_ERR_ERROR)
            {
                // grab error
                break;
            }
            else if(nErrorImage == MCAM_ERR_TIMEOUT)
            {
                printf("[ERROR] - MCAM_ERR_TIMEOUT\n");
                break;
                //continue;
            }
            else
            {
                printf("[ERROR] - MCAM_ERR_TIMEOUT\n");
                break;
            }
        }
        else
        {
            printf("[INFO] - Image: %lu, %.2X\r",nImageCounter++, pPixel[0]);      
            
            if(nImageCounter == 1000)
                break;
        }
    }
    
    dparams->Kill = TRUE;
    
    nTimeStop = GetTickCount();
    
    nTime = (double)(nTimeStop - nTimeStart);
    nFps = (double)nImageCounter  / nTime * 1000;
    printf("[INFO] - %2.1f Frames Per Second\n",nFps);
    
    nTimeStart = GetTickCount();

    // stop acquisition continuous mode
    nError = ST_AcqStop(dparams->Device);
    if(nError)
    {
        printf("[ERROR] - ST_AcqStop: %d\n", nError);
        goto END;
    }
    
    nTimeStop = GetTickCount();
    printf("[INFO] - Elapsed time to Acqusition stop : %d ms\n", nTimeStop - nTimeStart);
    
    ST_GetTotalPacketCount(dparams->Device, &nNumImagesAcquired, &nNumImagesMissing);
    printf("[INFO] - ImagesAcquired : %lu, MissingImage: %lu\n", nNumImagesAcquired, nNumImagesMissing);
    
END:
    if(pPixel)
        free(pPixel);
    
    return 0;

}

DWORD GetTickCount(void)
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (DWORD)((ts.tv_sec * 1000) + (ts.tv_nsec / 1000000));
}

