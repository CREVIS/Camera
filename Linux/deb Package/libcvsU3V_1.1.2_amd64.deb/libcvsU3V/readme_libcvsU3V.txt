CREVIS U3V for Linux(Ubuntu 18.04 and later)

1. Directories

    ConsoleDemo			-> linux console demo application
    Extra			-> include XML schema
    includes			-> include Header
    libs			-> linux cvsU3V library   


2. Install required libraries (as root or using sudo)
    
    - libusb
    - libxml2
    - libxslt
    - C++ Compiler
    
    Install on Ubuntu
    apt-get install libxml2 libxml2-dev libxslt1.1 libxslt1-dev libusb-1.0-0 libusb-1.0-0-dev libudev1 libudev-dev g++


3. Build the linux console demo application

    Command: ConsoleDemo/Linux64
             make
             ./Release/ConsoleDemo

 
4. If you don't execute it with sudo

   sudo cp 59-usb3vision.rules /etc/udev/rules.d
   sudo service udev restart	

   or 
   
   changing in /lib/udev/rules.d/50-udev-default.rules 

   # 'libusb' device nodes
   SUBSYSTEM=="usb", ENV{DEVTYPE}=="usb_device", MODE="0664"

   to

   # 'libusb' device nodes
   SUBSYSTEM=="usb", ENV{DEVTYPE}=="usb_device", MODE="0666"


