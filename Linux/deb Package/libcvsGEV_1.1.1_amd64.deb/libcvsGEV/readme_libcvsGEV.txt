CREVIS GEV for Linux(Ubuntu 18.04 and later)

1. Directories

    ConsoleDemo			-> linux console demo application
    Extra			-> include XML schema
    includes			-> include Header
    libs			-> linux cvsGEV library   


2. Install required libraries (as root or using sudo)
   
    - libxml2
    - libxslt
    - C++ Compiler
    
    Install on Ubuntu
    apt-get install libxml2 libxml2-dev libxslt1.1 libxslt1-dev g++


3. Build the linux console demo application

    Command: ConsoleDemo/Linux64
             make
             ./Release/ConsoleDemo 


