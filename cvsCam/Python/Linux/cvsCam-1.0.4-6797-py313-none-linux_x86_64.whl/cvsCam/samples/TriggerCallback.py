import ctypes
import time

import cvsCam

kb = cvsCam.cvsKb()

opencv_is_available=True
try:
    import cv2
    opencv_version=cv2.__version__
except:
    opencv_is_available=False
    print("Warning: This sample requires python3-opencv to display a window")

_recv_img_flag = False
_recv_img = cvsCam.CVS_BUFFER()

def on_receive(eventId, buffer, user_data):
    global _recv_img_flag

    recv_buffer = ctypes.cast(buffer, ctypes.POINTER(cvsCam.CVS_BUFFER)).contents
    ctypes.memmove(ctypes.byref(_recv_img), ctypes.byref(recv_buffer), ctypes.sizeof(recv_buffer))
    
    _recv_img_flag = True

def main():
    try:
        # Create a CVS system object
        cvsSystem = cvsCam.CvsSystem()

        # Update the device list
        cvsSystem.UpdateDevice()
        
        # Get the number of available cameras
        numCameras = cvsSystem.GetAvailableCameraNum()
        if numCameras == 0:
            raise Exception("[INFO] - No device found")

        try:
            # Create a CVS device object with the first camera
            cvsDevice = cvsCam.CvsDevice(0)

            # Open the device
            cvsDevice.Open()

            print("Trigger Callback Grab\n")
            print("-----------------------------")
            input("Press <Enter> to start.")

            # set Trigger Mode
            cvsDevice.SetEnumReg("TriggerMode", "On")

            # get Trigger Source
            trigger_source = cvsDevice.GetEnumReg("TriggerSource")
            
            # register grab callback
            global _recv_img_flag
            cvsDevice.RegisterGrabCallback(cvsCam.EVENT_NEW_IMAGE, on_receive, None)

            # Start the acquisition
            cvsDevice.AcqStart()

            # Grab Loop
            kb.start()
            while not kb.is_stopping():
                try:
                    if trigger_source == "Software":
                        cvsDevice.SetCmdReg("TriggerSoftware")           

                    if _recv_img_flag is True: 
                        img_data = ctypes.cast(_recv_img.image.pImage, ctypes.POINTER(ctypes.c_uint8))  
                        print(f"BlockID: {_recv_img.blockID:016d} TimeStamp: {_recv_img.timestamp:016d} Image: {img_data[0]:03d}", end='\r')    

                        if opencv_is_available:
                            img = cvsCam.ConvertToNumpy(_recv_img)
                            cv2.imshow("Image", img)

                            if cv2.waitKey(1) & 0xFF != 0xFF:
                                break

                        _recv_img_flag = False

                    time.sleep(0.01)

                except Exception as err:
                    print(err)
                    break

                if kb.kbhit():
                    print()
                    kb.getch()
                    break;
            
            kb.stop()

            if opencv_is_available:
                cv2.destroyAllWindows()
            
            # Stop the acquisition
            cvsDevice.AcqStop()

            # Unregister the grab callback
            cvsDevice.UnregisterGrabCallback(cvsCam.EVENT_NEW_IMAGE)

            # Close the device
            cvsDevice.Close()

            # Free the CVS system object
            cvsSystem.Free()
            input("\nPress enter to exit...")

        except Exception as err:
            cvsDevice.AcqStop()
            cvsDevice.Close()
            raise err

    except Exception as err:
        print(err)
        if 'cvsSystem' in locals():
            cvsSystem.Free()

if __name__ == "__main__":
    main()