"""
This module provides functions to retrieve device information before and after opening a device using the CREVIS camera.
Functions:
    GetInformationBeforeOpen(cvsSystem, enumNum=0):
        Retrieves and prints device information before opening the device.
        Parameters:
            cvsSystem (CREVIS.CvsSystem): The CvsSystem object.
            enumNum (int): The enumeration number of the device (default is 0).
    GetInformationAfterOpen(cvsDevice):
        Retrieves and prints device information after opening the device.
        Parameters:
            cvsDevice (CREVIS.CvsDevice): The CvsDevice object.
    main():
        The main function that initializes the CvsSystem, retrieves device information before and after opening the device, and handles exceptions.
"""

import cvsCam

def GetInformationBeforeOpen(cvsSystem, enumNum=0):
    try:
        print(f"User ID: {cvsSystem.GetEnumDeviceInfo(enumNum, cvsCam.MCAM_DEVICEINFO_USER_ID)}")
        print(f"Model Name: {cvsSystem.GetEnumDeviceInfo(enumNum, cvsCam.MCAM_DEVICEINFO_MODEL_NAME)}")
        print(f"Serial Number: {cvsSystem.GetEnumDeviceInfo(enumNum, cvsCam.MCAM_DEVICEINFO_SERIAL_NUMBER)}")
        print(f"Device Version: {cvsSystem.GetEnumDeviceInfo(enumNum, cvsCam.MCAM_DEVICEINFO_DEVICE_VERSION)}")
    except Exception as err:
        raise err
    
def GetInformationAfterOpen(cvsDevice):
    try:
        val = cvsDevice.GetStrReg("DeviceModelName")
        print(f"Device Model Name: {val}")
        val = cvsDevice.GetStrReg("DeviceID")
        print(f"Device ID: {val}")
        val = cvsDevice.GetStrReg("DeviceVersion")
        print(f"Device Version: {val}")
        val = cvsDevice.GetStrReg("DeviceVendorName")
        print(f"Device Vendor Name: {val}")
        val = cvsDevice.GetStrReg("DeviceManufacturerInfo")
        print(f"Device Manufacturer Info: {val}")
        val = cvsDevice.GetStrReg("DeviceUserID")
        print(f"Device User ID: {val}")

    except Exception as err:
        raise err

def main():
    try:
        # Create a CVS system object
        cvsSystem = cvsCam.CvsSystem()

        # Update the device list
        cvsSystem.UpdateDevice()
        
        # Get the number of available cameras
        numCameras = cvsSystem.GetAvailableCameraNum()
        if numCameras == 0:
            raise Exception("[INFO] - No device found")
        
        try:
            # Get information before open
            GetInformationBeforeOpen(cvsSystem)
        except Exception as err:
            raise err
        
        print()

        try:
            # Create a CVS device object with the first camera
            cvsDevice = cvsCam.CvsDevice(0)

            # Open the device
            cvsDevice.Open()

            GetInformationAfterOpen(cvsDevice)

            # Close the device
            cvsDevice.Close()

            # Free the CVS system object
            cvsSystem.Free()
            input("\nPress enter to exit...")

        except Exception as err:
            cvsDevice.AcqStop()
            cvsDevice.Close()
            raise err

    except Exception as err:
        print(err)
        if 'cvsSystem' in locals():
            cvsSystem.Free()

if __name__ == "__main__":
    main()