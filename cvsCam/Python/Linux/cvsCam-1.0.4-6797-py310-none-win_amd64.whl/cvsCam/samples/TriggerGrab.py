"""
TriggerGrab.py
This script demonstrates how to use the CREVIS camera system to grab images using a trigger mode.
Modules:
    ctypes: Provides C compatible data types and allows calling functions in DLLs or shared libraries.
    cvsCam: Custom module for interacting with CREVIS cameras.
    cv2: OpenCV module for image processing (optional).
Functions:
    main(): Main function to execute the trigger grab process.
Usage:
    Run the script and follow the prompts to start the image acquisition process. The script will display the grabbed images in a window if OpenCV is available.
Details:
    - Initializes the CvsSystem and updates the device list.
    - Checks for available cameras and raises an exception if none are found.
    - Opens the first available camera device.
    - Sets the trigger mode and starts the acquisition process.
    - Enters a grab loop where images are captured and displayed.
    - Handles keyboard interrupts to stop the acquisition process.
    - Cleans up by stopping the acquisition, closing the device, and freeing the CvsSystem object.
Exceptions:
    Raises exceptions for various error conditions, including no devices found, grab image timeout, and other runtime errors.
"""

import ctypes

import cvsCam

kb = cvsCam.cvsKb()

opencv_is_available=True
try:
    import cv2
    opencv_version=cv2.__version__
except:
    opencv_is_available=False
    print("Warning: This sample requires python3-opencv to display a window")

def main():
    try:
        # Create a CVS system object
        cvsSystem = cvsCam.CvsSystem()

        # Update the device list
        cvsSystem.UpdateDevice()
        
        # Get the number of available cameras
        numCameras = cvsSystem.GetAvailableCameraNum()
        if numCameras == 0:
            raise Exception("[INFO] - No device found")

        try:
            # Create a CVS device object with the first camera
            cvsDevice = cvsCam.CvsDevice(0)

            # Open the device
            cvsDevice.Open()

            print("Trigger Grab\n")
            print("-----------------------------")
            input("Press <Enter> to start.")

            # set Trigger Mode
            cvsDevice.SetEnumReg("TriggerMode", "On")

            # get Trigger Source
            trigger_source = cvsDevice.GetEnumReg("TriggerSource")
            
            # Start the acquisition
            cvsDevice.AcqStart()

            # Grab Loop
            kb.start()
            while not kb.is_stopping():
                try:
                    if trigger_source == "Software":
                        cvsDevice.SetCmdReg("TriggerSoftware")

                    recv_img = cvsDevice.GrabImage()
                    img_data = ctypes.cast(recv_img.image.pImage, ctypes.POINTER(ctypes.c_uint8))  
                    print(f"BlockID: {recv_img.blockID:016d} TimeStamp: {recv_img.timestamp:016d} Image: {img_data[0]:03d}", end='\r')    

                    if opencv_is_available:
                        img = cvsCam.ConvertToNumpy(recv_img)
                        cv2.imshow("Image", img)

                        if cv2.waitKey(1) & 0xFF != 0xFF:
                            break

                except Exception as err:
                    # If the error contains -1011
                    if "-1011" in str(err):
                        print("[INFO] - GrabImage timeout")
                        # continue
                    else:
                        print(err)
                        break

                if kb.kbhit():
                    kb.getch()
                    break;
            
            kb.stop()

            if opencv_is_available:
                cv2.destroyAllWindows()
            
            # Stop the acquisition
            cvsDevice.AcqStop()

            # Close the device
            cvsDevice.Close()

            # Free the CVS system object
            cvsSystem.Free()
            input("\nPress enter to exit...")

        except Exception as err:
            cvsDevice.AcqStop()
            cvsDevice.Close()
            raise err

    except Exception as err:
        print(err)
        if 'cvsSystem' in locals():
            cvsSystem.Free()

if __name__ == "__main__":
    main()