import ctypes
from enum import Enum
from ctypes import POINTER
import cvsCam_python

# Grab Event
EVENT_NEW_IMAGE = 0x0
EVENT_GRAB_ERROR = 0x1
EVENT_GRAB_TIMEOUT = 0x2

# Device Event
EVENT_DEVICE_DISCONNECT = 0x0010  # GEV, U3V
EVENT_EXPOSURE_END = 0x0014  # GEV, U3V
EVENT_ACQUISITION_TRANSFER_START = 0x0018  # GEV
EVENT_ACQUISITION_TRANSFER_END = 0x001C  # GEV
EVENT_OVER_TRIGGER = 0x0020  # GEV
EVENT_OVER_TRIGGER_START_MISSED = 0x0024  # U3V
EVENT_OVER_TRIGGER_END_MISSED = 0x0028  # U3V
EVENT_TRIGGER_START = 0x002C  # U3V
EVENT_WARNING_TEMPERATURE_STATE = 0x0030  # U3V
EVENT_CRITICAL_TEMPERATURE_STATE = 0x0034  # U3V

# Define Error Codes
MCAM_ERR_OK = 0
MCAM_ERR_GENERIC_ERROR = -1001
MCAM_ERR_NOT_INITIALIZED = -1002
MCAM_ERR_NOT_IMPLEMENTED = -1003
MCAM_ERR_BUSY = -1004
MCAM_ERR_STATE_ERROR = -1005
MCAM_ERR_NOT_CONNECTED = -1006
MCAM_ERR_NOT_FOUND = -1007
MCAM_ERR_NO_MORE_ITEM = -1008
MCAM_ERR_INVALID_PARAMETER = -1009
MCAM_ERR_FILE_ERROR = -1010
MCAM_ERR_TIMEOUT = -1011
MCAM_ERR_ABORTED = -1012
MCAM_ERR_BUFFER_TOO_SMALL = -1013
MCAM_ERR_CANNOT_OPEN_FILE = -1014
MCAM_ERR_THREAD_ERROR = -1015
MCAM_ERR_INVALID_DATA_FORMAT = -1016
MCAM_ERR_NOT_ENOUGH_MEMORY = -1017
MCAM_ERR_CANCEL = -1018
MCAM_ERR_PENDING = -1019
MCAM_ERR_NO_LICENSE = -1020
MCAM_ERR_CANT_READ_MANIFEST = -1021
MCAM_ERR_NOT_SUPPORTED = -1022
MCAM_ERR_ERR_OVERFLOW = -1023
MCAM_ERR_IMAGE_ERROR = -1024
MCAM_ERR_MISSING_PACKETS = -1025
MCAM_ERR_TOO_MANY_RESENDS = -1026
MCAM_ERR_RESENDS_FAILURE = -1027
MCAM_ERR_TOO_MANY_CONSECUTIVE_RESENDS = -1028
MCAM_ERR_AUTO_ABORTED = -1029
MCAM_ERR_BAD_VERSION = -1030
MCAM_ERR_NO_MORE_ENTRY = -1031
MCAM_ERR_NO_AVAILABLE_DATA = -1032
MCAM_ERR_NETWORK_ERROR = -1033
MCAM_ERR_RESYNC = -1034
MCAM_ERR_CORRUPTED_DATA = -1035
MCAM_ERR_GENICAM_XML_ERROR = -1036
MCAM_ERR_NO_DEVICE = -1037
MCAM_ERR_NO_SYSTEM = -1038
MCAM_ERR_NOT_OPEN_SYSTEM = -1039

# DeviceInfo
MCAM_DEVICEINFO_USER_ID = 10000
MCAM_DEVICEINFO_MODEL_NAME = 10001
MCAM_DEVICEINFO_SERIAL_NUMBER = 10002
MCAM_DEVICEINFO_DEVICE_VERSION = 10003
MCAM_DEVICEINFO_MAC_ADDRESS = 10004  # GEV
MCAM_DEVICEINFO_IP_ADDRESS = 10005  # GEV
MCAM_DEVICEINFO_CURRENT_SPEED = 10006  # U3V

# XML Version
XML_VERSION_1_0 = 0
XML_VERSION_1_1 = 1

# Parameters Visibility
VISIBILITY_BEGINNER = 0
VISIBILITY_EXPERT = 1
VISIBILITY_GURU = 2
VISIBILITY_INVISIBLE = 3

class ConvertColor(Enum):
    CVP_BGR2RGB = 4  # Convert from BGR to RGB color space.
    CVP_RGB2BGR = 4  # Convert from RGB to BGR color space.
    CVP_BayerBG2RGB = 48  # Convert from BayerBG to RGB color space.
    CVP_BayerGB2RGB = 49  # Convert from BayerGB to RGB color space.
    CVP_BayerRG2RGB = 46  # Convert from BayerRG to RGB color space.
    CVP_BayerGR2RGB = 47  # Convert from BayerGR to RGB color space.
    CVP_YUV2RGB_UYVY = 107  # Convert from YUV to RGB color space with UYVY format.
    CVP_YUV2BGR_UYVY = 108  # Convert from YUV to BGR color space with UYVY format.
    CVP_YUV2RGB_YVYU = 117  # Convert from YUV to RGB color space with YVYU format.
    CVP_YUV2BGR_YVYU = 118  # Convert from YUV to BGR color space with YVYU format.
    CVP_YUV2RGB_YUYV = 115  # Convert from YUV to RGB color space with YUYV format.
    CVP_YUV2BGR_YUYV = 116  # Convert from YUV to BGR color space with YUYV format.

class CVS_IMAGE(ctypes.Structure):
    _fields_ = [
        ("width", ctypes.c_int32),  # The width of the image.
        ("height", ctypes.c_int32),  # The height of the image.
        ("step", ctypes.c_int32),  # The number of bytes per line.
        ("channels", ctypes.c_int32),  # The number of channels per pixel.
        ("pImage", ctypes.POINTER(ctypes.c_void_p)),  # Pointer to the image memory.
    ]

class CVS_BUFFER(ctypes.Structure):
    _fields_ = [
        ("blockID", ctypes.c_uint64),  # The block ID of the buffer.
        ("timestamp", ctypes.c_uint64),  # The timestamp of the buffer.
        ("size", ctypes.c_uint32),  # The size of the buffer.
        ("image", CVS_IMAGE),  # The image data of the buffer.
    ]

class CVS_EVENT(ctypes.Structure):
    _fields_ = [
        ("id", ctypes.c_int),  # The ID of the event.
        ("timestamp", ctypes.c_uint64),  # The timestamp of the event.
        ("data", ctypes.c_void_p),  # Pointer to the event data.
        ("dataLength", ctypes.c_uint32),  # The length of the event data.
    ]

def cvtColor(src, code):
    try:
        return cvsCam_python.cvtColor(src, code)
    except Exception as e:
        raise e

def ConvertToNumpy(buffer):
    try:
        return cvsCam_python.ConvertToNumpy(buffer)
    except Exception as e:
        raise e

class CvsSystem:
    def __init__(self):
        try:
            self.cvsSystem = cvsCam_python.CvsSystem()
        except Exception as e:
            raise e

    def Free(self):
        try:
            self.cvsSystem.Free()
        except Exception as e:
            raise e

    def UpdateDevice(self):
        try:
            self.cvsSystem.UpdateDevice()
        except Exception as e:
            raise e

    def GetAvailableCameraNum(self):
        try:
            return self.cvsSystem.GetAvailableCameraNum()
        except Exception as e:
            raise e

    def GetEnumDeivceID(self, index):
        try:
            return self.cvsSystem.GetEnumDeivceID(index)
        except Exception as e:
            raise e

    def GetEnumDeviceInfo(self, index, info):
        try:
            return self.cvsSystem.GetEnumDeviceInfo(index, info)
        except Exception as e:
            raise e


class CvsDevice:
    def __init__(self, enumNumber):
        try:
            self.cvsDevice = cvsCam_python.CvsDevice(enumNumber)
        except Exception as e:
            raise e

    def Open(self, detailedLog=False):
        try:
            self.cvsDevice.Open(detailedLog)
        except Exception as e:
            raise e

    def Close(self):
        try:
            self.cvsDevice.Close()
        except Exception as e:
            raise e

    def AcqStart(self):
        try:
            self.cvsDevice.AcqStart()
        except Exception as e:
            raise e

    def AcqStop(self):
        try:
            self.cvsDevice.AcqStop()
        except Exception as e:
            raise e

    def DoAbortGrab(self):
        try:
            self.cvsDevice.DoAbortGrab()
        except Exception as e:
            raise e

    def SetGrabTimeout(self, timeout):
        try:
            self.cvsDevice.SetGrabTimeout(timeout)
        except Exception as e:
            raise e

    def GetGrabTimeout(self):
        try:
            return self.cvsDevice.GetGrabTimeout()
        except Exception as e:
            raise e

    def SetBufferCount(self, count):
        try:
            self.cvsDevice.SetBufferCount(count)
        except Exception as e:
            raise e

    def GetBufferCount(self):
        try:
            return self.cvsDevice.GetBufferCount()
        except Exception as e:
            raise e

    def GrabImage(self) -> CVS_BUFFER:
        try:
            return self.cvsDevice.GrabImage()
        except Exception as e:
            raise e

    def SingleGrabImage(self) -> CVS_BUFFER:
        try:
            return self.cvsDevice.SingleGrabImage()
        except Exception as e:
            raise e

    def GetImageAvailable(self):
        try:
            return self.cvsDevice.GetImageAvailable()
        except Exception as e:
            raise e

    def GetGrabCount(self):
        try:
            return self.cvsDevice.GetGrabCount()
        except Exception as e:
            raise e

    def GetFrameRate(self):
        try:
            return self.cvsDevice.GetFrameRate()
        except Exception as e:
            raise e

    def GetBandwidth(self):
        try:
            return self.cvsDevice.GetBandwidth()
        except Exception as e:
            raise e

    def GetLastError(self):
        try:
            return self.cvsDevice.GetLastError()
        except Exception as e:
            raise e

    def GetLastErrorDescription(self):
        try:
            return self.cvsDevice.GetLastErrorDescription()
        except Exception as e:
            raise e

    def SetDetailedLog(self, detailedLog):
        try:
            self.cvsDevice.SetDetailedLog(detailedLog)
        except Exception as e:
            raise e

    def GetDetailedLog(self):
        try:
            return self.cvsDevice.GetDetailedLog()
        except Exception as e:
            raise e

    def SetIntReg(self, regName, value):
        try:
            self.cvsDevice.SetIntReg(regName, value)
        except Exception as e:
            raise e

    def GetIntReg(self, regName):
        try:
            return self.cvsDevice.GetIntReg(regName)
        except Exception as e:
            raise e

    def SetFloatReg(self, regName, value):
        try:
            self.cvsDevice.SetFloatReg(regName, value)
        except Exception as e:
            raise e

    def GetFloatReg(self, regName):
        try:
            return self.cvsDevice.GetFloatReg(regName)
        except Exception as e:
            raise e

    def SetBoolReg(self, regName, value):
        try:
            self.cvsDevice.SetBoolReg(regName, value)
        except Exception as e:
            raise e

    def GetBoolReg(self, regName):
        try:
            return self.cvsDevice.GetBoolReg(regName)
        except Exception as e:
            raise e

    def SetEnumReg(self, regName, value):
        try:
            self.cvsDevice.SetEnumReg(regName, value)
        except Exception as e:
            raise e

    def GetEnumReg(self, regName):
        try:
            return self.cvsDevice.GetEnumReg(regName)
        except Exception as e:
            raise e

    def SetStrReg(self, regName, value):
        try:
            self.cvsDevice.SetStrReg(regName, value)
        except Exception as e:
            raise e

    def GetStrReg(self, regName):
        try:
            return self.cvsDevice.GetStrReg(regName)
        except Exception as e:
            raise e

    def SetCmdReg(self, regName):
        try:
            self.cvsDevice.SetCmdReg(regName)
        except Exception as e:
            raise e

    def GetIntRegRange(self, regName):
        try:
            return self.cvsDevice.GetIntRegRange(regName)
        except Exception as e:
            raise e

    def GetFloatRegRange(self, regName):
        try:
            return self.cvsDevice.GetFloatRegRange(regName)
        except Exception as e:
            raise e

    def GetEnumEntrySize(self, regName):
        try:
            return self.cvsDevice.GetEnumEntrySize(regName)
        except Exception as e:
            raise e

    def GetEnumEntryIntValue(self, regName, index):
        try:
            return self.cvsDevice.GetEnumEntryIntValue(regName, index)
        except Exception as e:
            raise e

    def GetEnumEntryValue(self, regName, index):
        try:
            return self.cvsDevice.GetEnumEntryValue(regName, index)
        except Exception as e:
            raise e

    def ReadParam(self, address, size):
        try:
            return self.cvsDevice.ReadParam(address, size)
        except Exception as e:
            raise e

    def WriteParam(self, address, size, value):
        try:
            self.cvsDevice.WriteParam(address, size, value)
        except Exception as e:
            raise e

    def ImportXML(self, filename):
        try:
            self.cvsDevice.ImportXML(filename)
        except Exception as e:
            raise e

    def ExportXML(self, filename, version, visibility):
        try:
            self.cvsDevice.ExportXML(filename, version, visibility)
        except Exception as e:
            raise e

    def ImportJson(self, filename):
        try:
            self.cvsDevice.ImportJson(filename)
        except Exception as e:
            raise e

    def ExportJson(self, filename, visibility):
        try:
            self.cvsDevice.ExportJson(filename, visibility)
        except Exception as e:
            raise e

    def RegisterGrabCallback(self, event, callback, user_data):
        try:
            self.cvsDevice.RegisterGrabCallback(event, callback, user_data)
        except Exception as e:
            raise e

    def UnregisterGrabCallback(self, event):
        try:
            self.cvsDevice.UnregisterGrabCallback(event)
        except Exception as e:
            raise e

from time import sleep
import signal

HostType = "Windows"
try:
    import msvcrt
except ImportError:
    import sys
    import termios
    import atexit
    from select import select
    HostType = "Posix"

class Singleton(type):
    _instances = {}
    def __call__(cls, *args, **kwargs):
        if cls not in cls._instances:
            cls._instances[cls] = super(Singleton, cls).__call__(*args, **kwargs)
        return cls._instances[cls]

# Keyboard handling
class cvsKb(metaclass = Singleton):
    __start_count = 0
    __stopping = False
    def __init__(self):
        if HostType == "Posix":
            self.fd = sys.stdin.fileno()
            self.new_term = termios.tcgetattr(self.fd)
            self.old_term = termios.tcgetattr(self.fd)
            self.new_term[3] = (self.new_term[3] & ~termios.ICANON & ~termios.ECHO)
            atexit.register(self.__set_normal_term)
    def start(self):
        self.__start_count += 1
        if self.__start_count == 1:
            signal.signal(signal.SIGINT, self.__set_stopping)
            self.__stopping = False
            self.__set_nb_term()
    def __set_stopping(self, signum, frame):
        self.__stopping = True
    def is_stopping(self) :
        return self.__stopping
    def __set_nb_term(self):
        if HostType == "Posix":
            termios.tcsetattr(self.fd, termios.TCSAFLUSH, self.new_term)
    def stop(self):
        self.__start_count -= 1
        if self.__start_count == 0:
            self.__set_normal_term()
            signal.signal(signal.SIGINT, signal.SIG_DFL)
    def __set_normal_term(self):
        if HostType == "Posix":
            termios.tcsetattr(self.fd, termios.TCSAFLUSH, self.old_term)
    def getch(self):
        if HostType == "Posix":
            return sys.stdin.read(1)
        else:
            return msvcrt.getch().decode('utf-8')
    def kbhit(self):
        if HostType == "Posix":
            return select([sys.stdin], [], [], 0) == ([sys.stdin], [], [])
        else:
            return msvcrt.kbhit()