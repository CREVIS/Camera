import ctypes
import threading
import queue

import cvsCam

kb = cvsCam.cvsKb()

opencv_is_available=True
try:
    import cv2
    opencv_version=cv2.__version__
except:
    opencv_is_available=False
    print("Warning: This sample requires python3-opencv to display a window")

def grab_thread(cam_idx, camera, stop_event, img_queue):
    while not stop_event.is_set():
        try:
            recv_img = camera.GrabImage()

            img_data = ctypes.cast(recv_img.image.pImage, ctypes.POINTER(ctypes.c_uint8))
            print(f"[Cam{cam_idx}] BlockID: {recv_img.blockID:016d} TimeStamp: {recv_img.timestamp:016d} Image: {img_data[0]:03d}", end='\r')

            if opencv_is_available:
                img = cvsCam.ConvertToNumpy(recv_img)
                try:
                    img_queue.put_nowait((cam_idx, img))
                except queue.Full:
                    pass  # drop frame if queue is full

        except Exception as err:
            if "-1011" in str(err):
                print(f"[Cam{cam_idx}] [INFO] - GrabImage timeout")
            else:
                print(f"[Cam{cam_idx}] [ERROR] - {err}")
                stop_event.set()

def main():
    try:
        # Create a CVS system object
        cvsSystem = cvsCam.CvsSystem()

        # Update the device list
        cvsSystem.UpdateDevice()
        
        # Get the number of available cameras
        numCameras = cvsSystem.GetAvailableCameraNum()
        if numCameras == 0:
            raise Exception("[INFO] - No device found")

        try:
            # Create a list of CVS device objects
            camera_list = []
            for i in range(numCameras):
                camera_list.append(cvsCam.CvsDevice(i))

            # Open the devices
            for camera in camera_list:
                camera.Open()

            print("Multiple Grab\n")
            print("-----------------------------")
            input("Press <Enter> to start.")
            
            # Start the acquisition
            for camera in camera_list:
                camera.AcqStart()
            
            # Grab Loop - each camera runs in its own thread
            stop_event = threading.Event()
            img_queue = queue.Queue(maxsize=numCameras * 2)
            threads = []
            for cam_idx in range(numCameras):
                t = threading.Thread(target=grab_thread, args=(cam_idx, camera_list[cam_idx], stop_event, img_queue), daemon=True)
                threads.append(t)
                t.start()

            kb.start()
            while not kb.is_stopping() and not stop_event.is_set():
                # Display images from queue in main thread (OpenCV GUI must run on main thread)
                if opencv_is_available:
                    try:
                        cam_idx, img = img_queue.get_nowait()
                        cv2.imshow(f"Camera {cam_idx}", img)
                    except queue.Empty:
                        pass

                    if cv2.waitKey(1) & 0xFF != 0xFF:
                        stop_event.set()

                if kb.kbhit():
                    kb.getch()
                    stop_event.set()

            stop_event.set()
            for t in threads:
                t.join(timeout=2.0)
            kb.stop()

            if opencv_is_available:
                cv2.destroyAllWindows()
            
            # Stop the acquisition
            for camera in camera_list:
                camera.AcqStop()

            # Close the device
            for camera in camera_list:
                camera.Close()

            # Free the CVS system object
            cvsSystem.Free()
            input("\nPress enter to exit...")

        except Exception as err:
            for camera in camera_list:
                camera.AcqStop()
                camera.Close()
            raise err

    except Exception as err:
        print(err)
        if 'cvsSystem' in locals():
            cvsSystem.Free()

if __name__ == "__main__":
    main()