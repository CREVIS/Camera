"""
CREVIS Camera Feature Control Script
This script demonstrates how to control various features of a CREVIS camera using the cvsCam library.
It includes functions to save, set, get, restore, and retrieve the range of camera features.
Functions:
    SaveFeature(cvsDevice):
        Saves the current values of camera features (Width, ExposureTime, LUTEnable, PixelFormat) and returns them as a dictionary.
    RestoreFeature(cvsDevice, saved):
        Restores camera features to the previously saved values.
    SetFeature(cvsDevice):
        Sets various features of the camera such as Width, ExposureTime, LUTEnable, PixelFormat, and TriggerSoftware.
    GetFeature(cvsDevice):
        Retrieves and prints the current settings of various camera features including Width, ExposureTime, LUTEnable, PixelFormat, and DeviceModelName.
    GetFeatureRange(cvsDevice):
        Retrieves and prints the range of values for various camera features including Width, ExposureTime, and PixelFormat.
    main():
        Main function that initializes the cvsSystem, updates the device list, saves original feature values,
        performs feature control operations, then restores the original values on the first available camera.
"""

import cvsCam

def SaveFeature(cvsDevice):
    try:
        saved = {}

        # Integer feature
        saved["Width"] = cvsDevice.GetIntReg("Width")

        # Float feature
        saved["ExposureTime"] = cvsDevice.GetFloatReg("ExposureTime")

        # Boolean feature
        saved["LUTEnable"] = cvsDevice.GetBoolReg("LUTEnable")

        # Enumeration feature
        saved["PixelFormat"] = cvsDevice.GetEnumReg("PixelFormat")

        return saved

    except Exception as err:
        raise err

def RestoreFeature(cvsDevice, saved):
    try:
        print("Restore Features...")

        cvsDevice.SetIntReg("Width", saved["Width"])
        cvsDevice.SetFloatReg("ExposureTime", saved["ExposureTime"])
        cvsDevice.SetBoolReg("LUTEnable", saved["LUTEnable"])
        cvsDevice.SetEnumReg("PixelFormat", saved["PixelFormat"])

        print()

    except Exception as err:
        raise err

def SetFeature(cvsDevice):
    try:
        print("Set Features...")

        # Integer feature
        cvsDevice.SetIntReg("Width", 640)

        # Float feature
        cvsDevice.SetFloatReg("ExposureTime", 3000.0)

        # Boolean feature
        cvsDevice.SetBoolReg("LUTEnable", True)

        # Enumeration feature
        cvsDevice.SetEnumReg("PixelFormat", "Mono8")

        # Command feature (Write only)
        cvsDevice.SetCmdReg("TriggerSoftware")

        print()

    except Exception as err:
        raise err

def GetFeature(cvsDevice):
    try:
        print("Get Features...")

        # Integer feature
        width = cvsDevice.GetIntReg("Width")
        print(f"Width : {width}")

        # Float feature
        exposureTime = cvsDevice.GetFloatReg("ExposureTime")
        print(f"ExposureTime : {exposureTime}")

        # Boolean feature
        lutEnable = cvsDevice.GetBoolReg("LUTEnable")
        print(f"LUTEnable : {lutEnable}")

        # Enumeration feature
        pixelFormat = cvsDevice.GetEnumReg("PixelFormat")
        print(f"PixelFormat : {pixelFormat}")

        # String feature(Read only)
        deviceModelName = cvsDevice.GetStrReg("DeviceModelName")
        print(f"DeviceModelName : {deviceModelName}")

        print()

    except Exception as err:
        raise err

def GetFeatureRange(cvsDevice):
    try:
        print("Get Features Range...")

        # Integer feature Range : min, max, increment
        min, max, inc = cvsDevice.GetIntRegRange("Width")
        print(f"Width range : Min = {min}, Max = {max}, Increment = {inc}")

        # Float feature Range : min, max
        min, max = cvsDevice.GetFloatRegRange("ExposureTime")
        print(f"ExposureTime range : Min = {min}, Max = {max}")

        # Enumeration feature Range : Entry size, Index, IntValue, StringValue
        entrySize = cvsDevice.GetEnumEntrySize("PixelFormat")
        print(f"PixelFormat entry size : {entrySize}")
        print("Index\tIntValue\tStringValue")

        for i in range(entrySize):
            intValue = cvsDevice.GetEnumEntryIntValue("PixelFormat", i)
            strValue = cvsDevice.GetEnumEntryValue("PixelFormat", i)
            print(f"{i}\t{intValue}\t{strValue}")

        print()

    except Exception as err:
        raise err

def main():
    try:
        # Create a CVS system object
        cvsSystem = cvsCam.CvsSystem()

        # Update the device list
        cvsSystem.UpdateDevice()
        
        # Get the number of available cameras
        numCameras = cvsSystem.GetAvailableCameraNum()
        if numCameras == 0:
            raise Exception("[INFO] - No device found")

        try:
            # Create a CVS device object with the first camera
            cvsDevice = cvsCam.CvsDevice(0)

            # Open the device
            cvsDevice.Open()

            # Save current feature values
            savedFeatures = SaveFeature(cvsDevice)
            print(f"Saved Features : {savedFeatures}")
            print()

            # Set the feature
            SetFeature(cvsDevice)

            # Get the feature            
            GetFeature(cvsDevice)

            # Get the feature range
            GetFeatureRange(cvsDevice)

            # Restore original feature values
            RestoreFeature(cvsDevice, savedFeatures)

            # Get the feature to verify restore
            GetFeature(cvsDevice)

            # Close the device
            cvsDevice.Close()

            # Free the CVS system object
            cvsSystem.Free()
            input("\nPress enter to exit...")

        except Exception as err:
            cvsDevice.Close()
            raise err

    except Exception as err:
        print(err)
        if 'cvsSystem' in locals():
            cvsSystem.Free()

if __name__ == "__main__":
    main()