import os

import cvsCam

def main():
    try:
        # Create a CVS system object
        cvsSystem = cvsCam.CvsSystem()

        # Update the device list
        cvsSystem.UpdateDevice()
        
        # Get the number of available cameras
        numCameras = cvsSystem.GetAvailableCameraNum()
        if numCameras == 0:
            raise Exception("[INFO] - No device found")

        try:
            # Create a CVS device object with the first camera
            cvsDevice = cvsCam.CvsDevice(0)

            # Open the device
            cvsDevice.Open()

            # Get the path to the desktop
            desktop_path = os.path.join(os.path.join(os.environ['USERPROFILE']), 'Desktop')
            print(f"Desktop path: {desktop_path}")

            # Create a folder on the desktop
            crevis_folder_path = os.path.join(desktop_path, 'CREVIS')
            if not os.path.exists(crevis_folder_path):
                os.makedirs(crevis_folder_path)

            # Export the camera settings to a JSON file
            xml_file_path = os.path.join(crevis_folder_path, 'camera_settings.xml')

            cvsDevice.ExportXML(xml_file_path, cvsCam.XML_VERSION_1_1, cvsCam.VISIBILITY_GURU)
            print(f"Exported camera settings to {xml_file_path}")

            # Import the camera settings from the XML file
            cvsDevice.ImportXML(xml_file_path)
            print(f"Imported camera settings from {xml_file_path}")

            # Close the device
            cvsDevice.Close()

            # Free the CVS system object
            cvsSystem.Free()
            input("\nPress enter to exit...")

        except Exception as err:
            cvsDevice.Close()
            raise err

    except Exception as err:
        print(err)
        if 'cvsSystem' in locals():
            cvsSystem.Free()

if __name__ == "__main__":
    main()