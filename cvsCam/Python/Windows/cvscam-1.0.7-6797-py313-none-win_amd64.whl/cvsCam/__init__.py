# cvsCam_python/__init__.py
from .cvsCam import *

__version__ = "1.0.7"