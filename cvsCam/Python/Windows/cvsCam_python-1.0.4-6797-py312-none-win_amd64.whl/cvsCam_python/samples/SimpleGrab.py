import ctypes

import cvsCam

kb = cvsCam.cvsKb()

opencv_is_available=True
try:
    import cv2
    opencv_version=cv2.__version__
except:
    opencv_is_available=False
    print("Warning: This sample requires python3-opencv to display a window")

def main():
    try:
        # Create a CVS system object
        cvsSystem = cvsCam.CvsSystem()

        # Update the device list
        cvsSystem.UpdateDevice()
        
        # Get the number of available cameras
        numCameras = cvsSystem.GetAvailableCameraNum()
        if numCameras == 0:
            raise Exception("[INFO] - No device found")

        try:
            # Create a CVS device object with the first camera
            cvsDevice = cvsCam.CvsDevice(0)

            # Open the device
            cvsDevice.Open()

            print("Simple Grab\n")
            print("-----------------------------")
            input("Press <Enter> to start.")
            
            # Start the acquisition
            cvsDevice.AcqStart()
            
            # Grab Loop
            kb.start()
            while not kb.is_stopping():
                try:
                    recv_img = cvsDevice.GrabImage()
                    
                    img_data = ctypes.cast(recv_img.image.pImage, ctypes.POINTER(ctypes.c_uint8))  
                    print(f"BlockID: {recv_img.blockID:016d} TimeStamp: {recv_img.timestamp:016d} Image: {img_data[0]:03d}", end='\r')

                    if opencv_is_available:
                        img = cvsCam.ConvertToNumpy(recv_img)
                        cv2.imshow("Image", img)

                        if cv2.waitKey(1) & 0xFF != 0xFF:
                            break

                except Exception as err:
                    # If the error contains -1011
                    if "-1011" in str(err):
                        print("[INFO] - GrabImage timeout")                        
                    else:
                        print(err)
                        break

                if kb.kbhit():
                    kb.getch()
                    break;
            
            kb.stop()

            if opencv_is_available:
                cv2.destroyAllWindows()
            
            # Stop the acquisition
            cvsDevice.AcqStop()

            # Close the device
            cvsDevice.Close()

            # Free the CVS system object
            cvsSystem.Free()
            input("\nPress enter to exit...")

        except Exception as err:
            cvsDevice.AcqStop()
            cvsDevice.Close()
            raise err

    except Exception as err:
        print(err)
        if 'cvsSystem' in locals():
            cvsSystem.Free()

if __name__ == "__main__":
    main()