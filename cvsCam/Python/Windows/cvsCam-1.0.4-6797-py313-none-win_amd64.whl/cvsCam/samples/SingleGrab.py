import ctypes

import cvsCam

def main():
    try:
        # Create a CVS system object
        cvsSystem = cvsCam.CvsSystem()

        # Update the device list
        cvsSystem.UpdateDevice()
        
        # Get the number of available cameras
        numCameras = cvsSystem.GetAvailableCameraNum()
        if numCameras == 0:
            raise Exception("[INFO] - No device found")

        try:
            # Create a CVS device object with the first camera
            cvsDevice = cvsCam.CvsDevice(0)

            # Open the device
            cvsDevice.Open()

            print("Single Grab\n")
            print("-----------------------------")
            input("Press <Enter> to start.")
            
            try:
                recv_img = cvsDevice.SingleGrabImage()
                img_data = ctypes.cast(recv_img.image.pImage, ctypes.POINTER(ctypes.c_uint8))  
                print(f"BlockID: {recv_img.blockID:016d} TimeStamp: {recv_img.timestamp:016d} Image: {img_data[0]:03d}", end='\r')
                
            except Exception as err:
                # If the error contains -1011
                if "-1011" in str(err):
                    print("[INFO] - GrabImage timeout")
                else:
                    print(err)
            
            # Close the device
            cvsDevice.Close()

            # Free the CVS system object
            cvsSystem.Free()
            input("\nPress enter to exit...")

        except Exception as err:
            cvsDevice.AcqStop()
            cvsDevice.Close()
            raise err

    except Exception as err:
        print(err)
        if 'cvsSystem' in locals():
            cvsSystem.Free()

if __name__ == "__main__":
    main()