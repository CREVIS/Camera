"""
This script demonstrates how to use the CREVIS camera to capture and display images with color conversion.
Modules:
    ctypes: Provides C compatible data types and allows calling functions in DLLs or shared libraries.
    cv2: OpenCV library for computer vision tasks.
    cvsCam: Custom module for interacting with CREVIS camera.
Functions:
    main(): Main function to execute the camera capture and display process.
Classes:
    None
Usage:
    Run the script and follow the on-screen instructions to start capturing images from the first available camera.
    The captured images will be displayed in a window with color conversion applied.
Exceptions:
    Raises an exception if no camera devices are found or if there are issues during image acquisition and processing.
Notes:
    - Ensure that the CREVIS camera system is properly installed and configured.
    - Press <Enter> to start the image acquisition process.
    - Press any key to stop the image acquisition process.
    - The script handles specific errors such as GrabImage timeout and general exceptions.
"""

import ctypes
import cv2

import cvsCam

kb = cvsCam.cvsKb()

def main():
    try:
        # Create a CVS system object
        cvsSystem = cvsCam.CvsSystem()

        # Update the device list
        cvsSystem.UpdateDevice()
        
        # Get the number of available cameras
        numCameras = cvsSystem.GetAvailableCameraNum()
        if numCameras == 0:
            raise Exception("[INFO] - No device found")

        try:
            # Create a CVS device object with the first camera
            cvsDevice = cvsCam.CvsDevice(0)

            # Open the device
            cvsDevice.Open()

            print("Color Convert\n")
            print("-----------------------------")
            input("Press <Enter> to start.")
            
            # Start the acquisition
            cvsDevice.AcqStart()
            
            # Grab Loop
            kb.start()
            while not kb.is_stopping():
                try:
                    recv_img = cvsDevice.GrabImage()
                    
                    img_data = ctypes.cast(recv_img.image.pImage, ctypes.POINTER(ctypes.c_uint8))  
                    print(f"BlockID: {recv_img.blockID:016d} TimeStamp: {recv_img.timestamp:016d} Image: {img_data[0]:03d}", end='\r')
                    
                    img = cvsCam.ConvertToNumpy(recv_img)
                    cvt_img = cvsCam.cvtColor(img, cvsCam.ConvertColor.CVP_BayerBG2RGB)                    
                    cv2.imshow("Image", cvt_img)

                    if cv2.waitKey(1) & 0xFF != 0xFF:
                        break

                except Exception as err:
                    # If the error contains -1011
                    if "-1011" in str(err):
                        print("[INFO] - GrabImage timeout")                        
                    else:
                        print(err)
                        break

                if kb.kbhit():
                    kb.getch()
                    break;
            
            kb.stop()

            cv2.destroyAllWindows()
            
            # Stop the acquisition
            cvsDevice.AcqStop()

            # Close the device
            cvsDevice.Close()

            # Free the CVS system object
            cvsSystem.Free()
            input("\nPress enter to exit...")

        except Exception as err:
            cvsDevice.AcqStop()
            cvsDevice.Close()
            raise err

    except Exception as err:
        print(err)
        if 'cvsSystem' in locals():
            cvsSystem.Free()

if __name__ == "__main__":
    main()